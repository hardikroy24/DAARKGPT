chroma-*.parquet files live here.  You can change this in your .env
