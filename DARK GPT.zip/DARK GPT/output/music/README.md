`output from typecast.ai`


https://user-images.githubusercontent.com/3261849/208031519-4eae5f87-bcda-4aac-a8cf-f143a04805fe.mp4


`query`

![query](https://user-images.githubusercontent.com/3261849/208017581-cc6cc89e-7b09-42c4-94db-d19238fee4d3.png)

`Album`
![album](https://user-images.githubusercontent.com/3261849/208017597-e7e84e58-b19d-415f-b6eb-3ab8b3dd8573.png)

`Poster`
![poster](https://user-images.githubusercontent.com/3261849/208017595-d8230382-66ba-4522-ba62-d4c14dc74676.png)

`Song`
![song](https://user-images.githubusercontent.com/3261849/208020729-30b65e07-19ad-44a1-89ab-982aa275e245.png)



`output from melobytes.com`

https://user-images.githubusercontent.com/3261849/208029569-e8e61195-cd3f-40b7-9f71-5cb6e916d440.mp4
